class Person:
    def __init__(self, first_name, last_name):
        self.first_name = first_name
        self.last_name = last_name


class Student(Person):
    def __init__(self, student_id, first_name, last_name, enroll_date):
        Person.__init__(self, first_name, last_name)        
        self.student_id = student_id
        self.enroll_date = enroll_date

        
class Professor(Person):
    def __init__(self, professor_id, first_name, last_name, hire_date):
        Person.__init__(self, first_name, last_name)
        self.professor_id = professor_id
        self.hire_date = hire_date

class Course:
    def __init__(self, course_id, title, credit_hours, professor):
        self.course_id = course_id
        self.title = title
        self.credit_hours = credit_hours
        self.professor = professor


class Enrollment:

    def __init__(self, enroll_id, student, course):

        self.enroll_id = enroll_id
        self.student = student
        self.course = course
        self.grade = ''

    def print_record(self):

        print(self.enroll_id,
              format(self.student.last_name, '15'),
              format(self.student.first_name, '15'),
              format(self.course.title, '20'),
              format(self.grade, '5'))

class Transcript:

    def __init__(self, enrollments):
        self.enrollments = enrollments

    def print_transcript(self, student):
        print("Student: ", student.first_name + ' ' + student.last_name)
        sum_credit_hours = 0
        sum_grade_points = 0        

        print("Course\t\t", "\tCredit hours", "\tCredit Points", "\tGrade Points", "\tLetter Grade") 
        
        for j in self.enrollments.values():
            
            if j.student.student_id == student.student_id:

                if j.grade in ["A", "B", "C", "D", "F"]:
                    sum_credit_hours += j.course.credit_hours
                    
                credit_points = self.__get_credit_points(j.grade)
                grade_points = j.course.credit_hours * credit_points

                sum_grade_points += grade_points

                print(format(j.course.title, "15"),
                      format(j.course.credit_hours, "16"),
                      format(credit_points, "15"),
                      format(grade_points, "15"), "\t", j.grade)
        print ()
        print(format(sum_credit_hours, '29'),
              format(sum_grade_points, '33'))

        if sum_credit_hours > 0:
            print("GPA: ", format(sum_grade_points / sum_credit_hours, '.2f'))
                

    def __get_credit_points(self, grade):

        credit_points = 0

        if grade == "A":
            credit_points = 4
        elif grade == "B":
            credit_points = 3
        elif grade == "C":
            credit_points = 2
        elif grade == "D":
            credit_points = 1
        elif grade == "F":
            credit_points = 0

        return credit_points
        

class Gradebook:
    def __init__(self):
        self.students = {}
        
        s = Student(1, "Carson", "Alexander", "09012005")
        self.students[s.student_id] = s
        s = Student(2, "Meredith", "Alonso", "09022002")
        self.students[s.student_id] = s
        s = Student(3, "Arturo", "Anand", "09032003")
        self.students[s.student_id] = s
        s = Student(4, "Gytis", "Barzdukas", "09012001")
        self.students[s.student_id] = s
        s = Student(5, "Peggy", "Justice", "09012001")
        self.students[s.student_id] = s
        s = Student(6, "Laura", "Norman", "09012003")
        self.students[s.student_id] = s
        s = Student(7, "Nino", "Olivetto", "09012005")
        self.students[s.student_id] = s

        self.professors = {}

        #professor_id   first_name   last_name  hire_date
        p = Professor(1, "Kim", "Abercrombie", "1995-03-11") 
        self.professors[p.professor_id] = p

        p = Professor(2, "Fadi", "Fakhouri", "2002-07-06") 
        self.professors[p.professor_id] = p

        p = Professor(3, "Roger", "Harui", "1998-07-01") 
        self.professors[p.professor_id] = p

        p = Professor(4, "Candace", "Kapoor", "2001-01-15")
        self.professors[p.professor_id] = p

        p = Professor(5, "Roger", "Zheng", "2004-02-12") 
        self.professors[p.professor_id] = p


       
        self.courses = {}
      
        c = Course(1050, "Chemistry", 3, self.professors[1])
        self.courses[c.course_id] = c
        c = Course(4022, "Microeconomics", 3, self.professors[2])
        self.courses[c.course_id] = c
        c = Course(4041, "Macroeconomics", 3, self.professors[3])
        self.courses[c.course_id] = c
        c = Course(1045, "Calculus", 4, self.professors[4])
        self.courses[c.course_id] = c
        c = Course(3141, "Trigonometry", 4, self.professors[5])
        self.courses[c.course_id] = c
        c = Course(2021, "Composition", 3, self.professors[1])
        self.courses[c.course_id] = c
        c = Course(2042, "Literature", 4, self.professors[2])
        self.courses[c.course_id] = c


        
        self.enrollments = {}
       
        enroll_id = 11050  # combine student id + course id
        enrollment = Enrollment(enroll_id, self.students[1], self.courses[1050])
        self.enrollments[enroll_id] = enrollment

        enroll_id = 14022  # combine student id + course id
        enrollment = Enrollment(enroll_id, self.students[1], self.courses[4022])
        self.enrollments[enroll_id] = enrollment

        enroll_id = 14041  # combine student id + course id
        enrollment = Enrollment(enroll_id, self.students[1], self.courses[4041])
        self.enrollments[enroll_id] = enrollment

        enroll_id = 21045  # combine student id + course id
        enrollment = Enrollment(enroll_id, self.students[2], self.courses[1045])
        self.enrollments[enroll_id] = enrollment

        enroll_id = 23141  # combine student id + course id
        enrollment = Enrollment(enroll_id, self.students[2], self.courses[3141])
        self.enrollments[enroll_id] = enrollment

        enroll_id = 22021  # combine student id + course id
        enrollment = Enrollment(enroll_id, self.students[2], self.courses[4041])
        self.enrollments[enroll_id] = enrollment

        enroll_id = 31050  # combine student id + course id
        enrollment = Enrollment(enroll_id, self.students[3], self.courses[1050])
        self.enrollments[enroll_id] = enrollment

        enroll_id = 41050  # combine student id + course id
        enrollment = Enrollment(enroll_id, self.students[4], self.courses[1050])
        self.enrollments[enroll_id] = enrollment

        enroll_id = 44022  # combine student id + course id
        enrollment = Enrollment(enroll_id, self.students[4], self.courses[4022])
        self.enrollments[enroll_id] = enrollment

        enroll_id = 54041  # combine student id + course id
        enrollment = Enrollment(enroll_id, self.students[5], self.courses[2021])
        self.enrollments[enroll_id] = enrollment

        enroll_id = 61045  # combine student id + course id
        enrollment = Enrollment(enroll_id, self.students[6], self.courses[1045])
        self.enrollments[enroll_id] = enrollment

        enroll_id = 73141 # combine student id + course id
        enrollment = Enrollment(enroll_id, self.students[7], self.courses[3141])
        self.enrollments[enroll_id] = enrollment

    UPGRADE = 1
    PRINT_GPA = 2
    DISPLAY = 3
    QUIT  = 4

    def main(self):
        choice = 0
        while choice != "4":
            choice = self.__get_menu_choice()

            if choice == "1":
                enroll_number = int(input("Enter enroll number: "))

                if enroll_number in self.enrollments:
                    enroll = self.enrollments.get(enroll_number)
                    grade = input("Enter grade for this course: ")
                    enroll.grade = grade
                else:
                    print ("Invalid enrollment ID")
            elif choice == "2":
                student_id = int(input("Enter student ID: "))
                if student_id in self.students:
                    student = self.students.get(student_id)
                    transcript = Transcript(self.enrollments)
                    transcript.print_transcript(student)
                else:
                    print("Invalid student ID")
                    
            elif choice == "3":
                for enrollment in self.enrollments.values ():
                    enrollment.print_record()
                
    def __get_menu_choice (self):
         print()
         print("ACADEMIC MAIN MENU")
         print()
         print("1. Update Grade")
         print("2. Print Student GPA")
         print("3. Print All Enrollments")
         print("4. Exit programe")
         print()

         return input("Enter your choice: ")
        

gradebook = Gradebook()
gradebook.main()



