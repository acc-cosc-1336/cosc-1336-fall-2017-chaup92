class Student:
    def __init__(self, student_id, fname, lname, day_enroll):
        self.student_id = student_id
        self.fname = fname
        self.lname = lname
        self.day_enroll = day_enroll
