class Enrollment:
    def __init__(self, enroll_id, student, course):
        self.enroll_id = enroll_id
        self.course = course
        self.student = student
