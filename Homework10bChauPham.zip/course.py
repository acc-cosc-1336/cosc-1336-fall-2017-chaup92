class Course:
    def __init__(self, course_id, title, credit_hours):
        self.course_id = course_id
        self.title = title
        self.credit_hours = credit_hours
